/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vpts_rules4.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjien-ji <tjien-ji@student.42kl.edu.my>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/29 18:38:40 by tjien-ji          #+#    #+#             */
/*   Updated: 2022/05/29 18:49:56 by tjien-ji         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef VPTS_RULES4_H
# define VPTS_RULES4_H

void	apply_vpts_rule4(short int solu_grid[][4], short int possi_grid[][4],
			short int *vpts);
#endif
