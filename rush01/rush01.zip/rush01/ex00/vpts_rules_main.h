/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vpts_rules_main.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjien-ji <tjien-ji@student.42kl.edu.my>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/29 18:46:30 by tjien-ji          #+#    #+#             */
/*   Updated: 2022/05/29 18:46:32 by tjien-ji         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef VPTS_RULES_MAIN_H
# define VPTS_RULES_MAIN_H

void	apply_vpts_rules(short int solu_grid[][4], short int possi_grid[][4],
			short int *vpts);
#endif
