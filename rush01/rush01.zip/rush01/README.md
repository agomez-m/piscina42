# C-Piscine-Rush01
42 School C Piscine rush01 - Skyscraper puzzle
This repo is now archived and will not be maintained actively, but will remain public for informational purposes.
If any change is desired, please fork this repo and make the changes in said fork instead.

Most (if not all) successful attempts in passing the rush01 project employ the back-tracking algorithm, or other brute-force methods. That is the most sensible choice given the limited time available before submission deadline. By doing so, one would not even need to figure out how to solve the puzzle, but instead would only need to know what a valid solution looks like. Not having to figure out the puzzle saves considerable amount of time, and helps greatly in making the deadline. 

This attempt in doing something different was not an exception to the above. At submission (commit d152bf), multiple critical bugs remained and the team failed the project. However, subsequent bugfixes were pushed to the repo, and the code is now in a working state, though no thorough testing was conducted. Some refactorization and optimization can still be done, but was deemed not worth the time considering other projects that follow.

This solver will not solve puzzles larger than 4-by-4. To scale up, more constraints would be needed. 
